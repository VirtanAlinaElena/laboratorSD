#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
int main()
{ 
	/* 5 noduri
		5 5
		1 2
		2 3
		3 4
		1 4
		2 4
	*/
	Graph g = initGraph(5);
	insertEdge(g, 5, 5);
	insertEdge(g, 1, 2);
	insertEdge(g, 2, 3);
	insertEdge(g, 3, 4);
	insertEdge(g, 1, 4);
	insertEdge(g, 2, 4);

	//dfs(g, 2);

	bfs(g, 1);

	int viz[5];
	for (int i = 0; i < 5; i++)
		viz[i] = 0;
	
	recursiveDFS(g, 1, viz);
	return 0;
}