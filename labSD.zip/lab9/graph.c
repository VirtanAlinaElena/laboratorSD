#include "graph.h"

//TODO - Implementati functiile pentru un graf neorientat

// Aloca memorie si initializeaza campurile structurii
Graph initGraph(int nrVarfuri)
{
	Graph g;
	g = malloc(sizeof(struct graph));
	g->adjLists = malloc(nrVarfuri * sizeof(struct graph));
	g->V = nrVarfuri;
	//g->dist = malloc(nrVarfuri * sizeof(struct graph));
	return g;
}

// Adauga muchia (u, v) in graf
Graph insertEdge(Graph g, int u, int v)
{
	g->adjLists[u] = addLast(g->adjLists[u], v);
	g->adjLists[v] = addLast(g->adjLists[v], u);

	return g;
}

// Sterge nodul v din graf
Graph deleteVertex(Graph g, int v)
{
	int i, val;
	List tmp = g->adjLists[v];

	while (tmp != NULL)
	{
		val = tmp->data;
		deleteItem(g->adjLists[val], v);
		tmp = tmp->next;
	}
	free(g->adjLists[v]);
	return g;
}

// Returneaza gradul intern al nodului v
int getInDegree(Graph g, int v)
{
	List tmp;
	int grad = 0;
	tmp = g->adjLists[v];
	while (tmp != NULL)
	{
		grad++;
		tmp = tmp->next;
	}
	return grad;
}

// Afiseaza graful
void printGraph(Graph g)
{
	int i, j, val;
	List tmp;
	for (i = 0; i < g->V; i++)
	{
		tmp = g->adjLists[i];
		while (tmp != NULL)
		{
			val = tmp->data;
			printf("%d ", val);
			tmp = tmp->next;
		}
	}
}

// coada, parcurgere in latime
void bfs(Graph g, int start)
{
	int viz[g->V];
	int i, val;
	Queue q = initQueue(start);
	List tmp;

	for (i = 0 ; i < g->V; i++)
		viz[i] = 0; // nodurile nu au fost in vizitate

	viz[start] = 1;
	q = enqueue(q, start);

	while  (!isEmptyQueue(q))
	{
		val = first(q);
		printf("%d ", val);
		q = dequeue(q);

		tmp = g->adjLists[val];
		while (tmp != NULL)
		{
			if (viz[tmp->data] == 0)
			{	
				viz[tmp->data] = 1;
				q = enqueue(q, tmp->data);
			}
			tmp = tmp->next;
		}
		
	}


}

// stiva, parcurgere in adancime
void dfs(Graph g, int start)
{
	Stack stack = initStack(start);
	int i, varf;
	int viz[g->V];
	List tmp;

	for (i = 0; i < g->V; i++)
		viz[i]  = 0;

	viz[start] = 1;
	//printf("%d ", start);

	while (!isEmptyStack(stack))
	{
		varf = top(stack);
		stack = pop(stack);
		
		printf("%d ", varf);
		tmp = g->adjLists[varf];
		while (tmp != NULL)
		{
			if (!viz[tmp->data])
			{
				stack = push(stack, tmp->data);
				viz[tmp->data] = 1;
			}
			tmp = tmp->next;
		}
	}

	// distanta
}

void recursiveDFS(Graph g, int start, int viz[])
{
	int i;
	Stack s = initStack(start);
	
	viz[start] = 1;
	printf("%d ", start);

	tmp = g->adjLists[start];
	while (tmp != NULL)
	{
		if (!viz[val])
			recursiveDFS(g, val, viz);
		tmp = tmp->next;
	}


}





//Functie care va deseneaza graful
void drawGraph(Graph g, char *name)
{
	int i, j;
	FILE *stream;
	char *buffer;
	List tmp;

	if (g == NULL || name == NULL)
		return;
	stream = fopen(name, "w");
	fprintf(stream, "graph G {\n");
	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
	for (i = 0; i < g->V; i++) {
		tmp = g->adjLists[i];
		while (tmp != NULL) {
			if (tmp->data > i)
				fprintf(stream, "    %d -- %d;\n", i, tmp->data);
			tmp = tmp->next;
		}
	}
	fprintf(stream, "}\n");
	fclose(stream);
	buffer = (char*) malloc(SIZE*sizeof(char));
	sprintf(buffer, "dot %s | neato -n -Tpng -o graph.png", name);
	system(buffer);
	free(buffer);
}