#include "graph.h"

Graph initGraph(int V) {
	Graph g;
	int i;
	g = (Graph) malloc(sizeof(struct graph));
	g->V = V;
	g->adjLists = (List*) malloc(V * sizeof(List));
	for (i = 0; i < V; i++) {
		g->adjLists[i] = NULL;
	}
	g->visited = calloc(V, sizeof(int));
	g->start = malloc(V * sizeof(int));
	g->end = malloc(V * sizeof(int));
	return g;
}

Graph insertEdge(Graph g, int u, int v, int cost) {
	Pair p;
	p.v = v;
	p.cost = cost;
	g->adjLists[u] = addLast(g->adjLists[u], p);
	return g;
}

Graph bfs(Graph g, int start) {
	int i, j;
	Queue q = NULL;
	List tmp;
	g->visited[start] = 1;
	q = enqueue(q, start);
	while(!isEmptyQueue(q)) {
		i = first(q);
		printf("%d\n", i);
		q = dequeue(q);
		tmp = g->adjLists[i];
		while (tmp != NULL) {
			j = tmp->data.v;
			if (g->visited[j] == 0) {
				q = enqueue(q, j);
				g->visited[j] = 1;
			}
			tmp = tmp->next;
		}
	}
	return g;
}

Graph dfs(Graph g, int start) {
	int i;
	List tmp;
	g->visited[start] = 1;
	printf("%d\n", start);
	tmp = g->adjLists[start];
	while (tmp != NULL) {
		i = tmp->data.v;
		if (g->visited[i] == 0)
			g = dfs(g, i);
		tmp = tmp->next;
	}
	return g;
}

Graph dfs2(Graph g, int start) {
	int i;
	List tmp;
	g->visited[start] = 1;
	tmp = g->adjLists[start];
	while (tmp != NULL) {
		i = tmp->data.v;
		if (g->visited[i] == 0)
			g = dfs2(g, i);
		tmp = tmp->next;
	}
	return g;
}


void topSort(Graph g)
{
	List tmp;
	Stack s = NULL, stack = NULL;
	
	int V = g->V;
	int u, i;
	int imuchii[V]; // vector care retine nr de muchii interne ale fiecarui nod
	int nrimuchii;

	// pentru fiecare nod
	for (u = 0; u < V; u++)
	{
		nrimuchii = 0; // pp ca nodul u nu are in-muchii

		// caut in listele de adiacenta ale vecinilor nodul u
		for (i = 0; i < V; i++)
		{
			tmp = g->adjLists[i];
			while (tmp != NULL)
			{
				if (tmp->data.v == u)
					nrimuchii++;
				tmp = tmp->next;
			}

		}
		
		if (nrimuchii == 0)
			s = push(s, u);

		imuchii[u] = nrimuchii;
	}

	while (!isEmptyStack(s))
	{
		u = top(s);
		s = pop(s); // scot un nod din multimea s
		stack = push(stack, u);

		tmp = g->adjLists[u];
		while (tmp != NULL)
		{
			imuchii[tmp->data.v]--;
			if (imuchii[tmp->data.v] == 0)
				s = push(s, tmp->data.v);
			tmp = tmp->next;
		}

	}

	// ok imi spune daca g are sau nu muchii
	int ok = 0; // pp ca g nu are muchii
	for (u = 0; u < V; u++)
		if (imuchii[u] != 0)
			ok = 1;


	if (ok != 0) // g are muchii
		printf("EROARE! GRAF CICLIC");
	else
	{
		while (!isEmptyStack(stack))
		{
			printf("%d ", top(stack));
			stack = pop(stack);
		}
	}
}

int exista_nod_nevizitat(Graph g)
{
	int i;
	for (i = 0; i < g->V; i++)
		if (g->visited[i] == 0)
			return i; // nodul care nu a fost vizitat
	return -1; // cazul in care toate nodurile au fost vizitate
}

int componenteConexe(Graph g)
{
	int comp = 0;
	int nod;
	int i;

	for (i = 0; i < g->V; i++)
	{
		g->visited = (int*) calloc(g->V, sizeof(int));
		dfs2(g, i);
		while (exista_nod_nevizitat(g) != -1)
		{
			nod = exista_nod_nevizitat(g);
			comp++;
			dfs2(g, nod);
		}
	}
	return comp;

}


// utilizez Roy-Floyd pentru a calcula drumul minim
void drumMinim(Graph g)
{
	int i, j, k, u;
	int a[g->V][g->V];
	for (i = 0; i < g->V; i++)
		for (j = 0; j < g->V; j++)
		{
			if (i == j)
				a[i][j] = 0;
			else
				a[i][j] = INF;
		}

	List tmp;
	for (u = 0; u < g->V; u++)
	{
		tmp = g->adjLists[u];
		while (tmp != NULL)
		{
			a[u][tmp->data.v] = tmp->data.cost;
			tmp = tmp->next;
		}
	}

	for (k = 0; k < g->V; k++)
		for (i = 0; i < g->V; i++)
			for (j = 0; j < g->V; j++)
					if (a[i][j] > a[i][k] + a[k][j])
						a[i][j] = a[i][k] + a[k][j];

	for (i = 0; i < g->V; i++)
	{
		for (j = 0; j < g->V; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
}

void afisDrumMinim(Graph g, int x, int y)
{
	int i, j, k, u;
	int a[g->V][g->V];
	for (i = 0; i < g->V; i++)
		for (j = 0; j < g->V; j++)
		{
			if (i == j)
				a[i][j] = 0;
			else
				a[i][j] = INF;
		}

	List tmp;
	for (u = 0; u < g->V; u++)
	{
		tmp = g->adjLists[u];
		while (tmp != NULL)
		{
			a[u][tmp->data.v] = tmp->data.cost;
			tmp = tmp->next;
		}
	}

	int c[g->V][g->V];
	for (i = 0; i < g->V; i++)
		for (j = 0; j < g->V; j++)
			c[i][j] = a[i][j];

	// matricea c este matricea de drum minim
	for (k = 0; k < g->V; k++)
		for (i = 0; i < g->V; i++)
			for (j = 0; j < g->V; j++)
					if (c[i][j] > c[i][k] + c[k][j])
						c[i][j] = c[i][k] + c[k][j];

	// BELLMAN-FORD
	int tata[g->V], d[g->V];
	for (i = 0; i < g->V; i++)
	{
		tata[i] = -1;
		d[i] = INF;
	}

	d[x] = 0;
	for (j = 0; j < g->V; j++)
		for (k = 0; k < g->V; k++)
			if (d[j] != INF && a[j][k] != INF && c[k][y] != INF)
			{
				if (d[k] > d[j] + a[j][k])
				{
					d[k] = d[j] + a[j][k];
					tata[k] = j;
				}
			}

	printf("%d ", x);
	while (x != y)
	{	
		for (i = 0; i < g->V; i++)
			if (tata[i] == x)
			{
				x = i;
				printf("%d ", i);
			}
	}

}

//Functie care va deseneaza graful
void drawGraph(Graph g, char *name)
{
	int i, j;
	FILE *stream;
	char *buffer;
	List tmp;

	if (g == NULL || name == NULL)
		return;
	stream = fopen(name, "w");
	fprintf(stream, "digraph G {\n");
	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
	for (i = 0; i < g->V; i++) {
		tmp = g->adjLists[i];
		while (tmp != NULL) {
			fprintf(stream, "    %d -> %d;\n", i, tmp->data.v);
			tmp = tmp->next;
		}
	}
	fprintf(stream, "}\n");
	fclose(stream);
	buffer = (char*) malloc(SIZE*sizeof(char));
	sprintf(buffer, "dot %s | neato -n -Tpng -o graph.png", name);
	system(buffer);
	free(buffer);
}
