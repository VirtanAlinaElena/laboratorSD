#include "graph.h"

int main(int argc, char **argv) {
	FILE *f;
	int i, n, m, x, y, cost;
	Graph g;
	if (argc < 2) {
		printf("./graph file.txt\n");
		return 1;
	}
	f = fopen(argv[1], "r");
	fscanf(f, "%d %d", &n, &m); // n - nr noduri
								// m - nr de legaturi
	g = initGraph(n);
	for (i = 0; i < m; i++) {
		fscanf(f, "%d %d %d", &x, &y, &cost);
		g = insertEdge(g, x, y, cost);
	}
	drawGraph(g, "graph.dot");
	//g = dfs(g, 0);

	printf("Problema 1: Sortarea topologica\n");
	topSort(g);
	printf("\n\n");

	printf("Prolema2: Numar componente conexe\n");
	printf("%d\n\n", componenteConexe(g));
	
	printf("Problema 3: Matricea drumurilor minime\n");
	drumMinim(g); 
	
	printf("\nProblema4: Afisarea nodurilor care constituie drumul minim de la x la y\n");
	printf("Drumul minim dintre 0 si 7:\n ");
	afisDrumMinim(g, 0, 7);
	printf("\n");

	printf("Drumul minim dintre 0 si 3:\n ");
	afisDrumMinim(g, 0, 3);
	printf("\n");

	return 0;
}