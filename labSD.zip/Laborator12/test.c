#include "hash.h"
#include <stdio.h>
#include "vector.h"
#include "hash.h"
#include <time.h>
#include <stdlib.h>

#define BUFMAX 100

typedef struct _vector {
	char name[100];
	int capacity;
	int size;
}* Vector;

int main(int argc, char** argv)
{
	// problema2
	FILE* f;
	f = fopen("words.txt", "r");
	int minCapacity = 10;
	List l = NULL;
	char buffer[BUFMAX];
	int test;
	Vector v;
	v = vec_init();
	v->size = 2500;
	while (fgets(buffer, BUFMAX, f) != NULL)
	{
		int hashIndex  = hash(buffer, 2500);
		//v = malloc(sizeof(Vector));
		v->data = (List*)malloc(2500 * sizeof(List));
		test = hashIndex;
		vec_ensureCapacity(v, minCapacity);
		l = list_init(buffer);

		// am gasit un element care are aceeasi cheie cu un alt element
		if (v->data[hashIndex] != NULL)
			vec_add(v, l);
			//v->data[hashIndex] = list_prepend(v->data[hashIndex], buffer);
		else
			vec_set(v, hashIndex, l);	// v[hashIndex]->data = l;
	//	delete_list(l);
	}


	int time1 = 0;
	int time2 = 0;
	time1 = time(NULL);
	l = vec_at(v, test);
	time2 = time(NULL);
	printf("%d", time2 - time1);
	
	fclose(f);

	// // problema3
	Vector v;
	v = vec_init();
	v->size = 2500;




}