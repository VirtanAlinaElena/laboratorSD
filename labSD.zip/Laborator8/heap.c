#include "heap.h"

Heap initHeap(int (*compare_func) (const void*, const void*)) {
	Heap h;
	h = malloc(sizeof(struct heap)); 
	h->size = 0;
	h->capacity = MAX;
	h->compare_func = compare_func;
	return h;
}

void swap(Type v[], int i, int j)
{
	Type aux;
	aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

// Heap siftDown(Heap h, int index) {
// 	int left = index * 2 + 1;
// 	int right = index * 2 + 2;
// 	while (left < h->size - 1)
// 	{
// 		// daca exista si fiul stang, si fiul drept
// 		if (left <= h->size - 1 && right <= h->size - 1)
// 			if (h->compare_func(&h->vector[left], &h->vector[right]) > 0)
// 			{
// 				swap(h->vector, index, left);
// 				index = left;
// 			}
// 			else
// 			{
// 				swap(h->vector, index, right);
// 				index = right;
// 			}

// 		// daca exista doar fiul stang
// 		if (left <= (h->size - 1) && right > (h->size - 1))
// 			if (h->compare_func(&h->vector[left], &h->vector[index]) > 0)
// 			{
// 				swap(h->vector, index, left);
// 				index = left;
// 			}
	
// 		left = index * 2 + 1;
// 		right = index * 2 + 2;
// 	}

// 	return h;
// }

Heap siftDown(Heap h, int index) {
	int maxIndex = index;
	int left = index * 2 + 1;
	int right = index * 2 + 2;

	if (left < h->size)
		if(h->compare_func(&h->vector[left], &h->vector[maxIndex]) > 0)
			maxIndex = left;

	if (right < h->size)
		if (h->compare_func(&h->vector[right], &h->vector[maxIndex]) > 0)
			maxIndex = right;

	if (index != maxIndex)
	{
		swap(h->vector, index, maxIndex);
		h = siftDown(h, maxIndex);
	}
	return h;
}

Heap siftUp(Heap h, int index) {
	int parent;
	parent = (index - 1)/2;
	while (h->compare_func(&h->vector[index], &h->vector[parent]) > 0)
	{
		swap(h->vector, index, parent);
		index = parent;
		if (index == 0)
			break;
		parent = (index - 1) / 2;
	}
	return h;
}

//Heap swapAndSiftDown(Heap h, int parent, int child) {
//	return NULL;
//}

Heap insertHeap(Heap h, Type element) {
	int index;

	if (h->size == 0)
	{
		h->vector[h->size] = element;
		h->size++;
		return h;
	}
	else
	{
		h->vector[h->size] = element;
		h->size++;
		index = h->size - 1;
		siftUp(h, index);

	}
	return h;
}

Type extractMax(Heap h) {
	int index, left, right;
	Type Max;
	// daca nu am niciun element in heap
	//if (h->size == 0)
	//	return -1;

	Max = h->vector[0];
	h->vector[0] = h->vector[h->size - 1];
	h->size = h->size - 1;

	index = 0;
	h = siftDown(h, index);
	return Max;
}

Heap freeHeap(Heap h) {
	free(h);
	return h;
}
