#include "huffman.h"

void drawHeapAux(Heap h, int index, FILE* stream) {
    static int nullcount = 0;

    if (2 * index + 1 < h->size) {
    	int left = 2 * index + 1;
        fprintf(stream, "    %lf -> %lf;\n", h->vector[index]->frequency, h->vector[left]->frequency);
        drawHeapAux(h, left, stream);
    }
    if (2 * index + 2 < h->size) {
    	int right = 2 * index + 2;
        fprintf(stream, "    %lf -> %lf;\n", h->vector[index]->frequency, h->vector[right]->frequency);
        drawHeapAux(h, right, stream);
    }
}

void drawHeap(Heap h, int index, char *fileName) {
	FILE* stream = fopen("test.dot", "w");
	char buffer[SIZE];
    fprintf(stream, "digraph HEAP {\n");
    fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
    if (!h)
        fprintf(stream, "\n");
    else if (2 * index + 1 > h->size)
        fprintf(stream, "    %lf;\n", h->vector[index]->frequency);
    else
        drawHeapAux(h, index, stream);
    fprintf(stream, "}\n");
    fclose(stream);
    sprintf(buffer, "dot test.dot | neato -n -Tpng -o %s", fileName);
	system(buffer);
}

int treeNode_compare(const void* a_pointer, const void* b_pointer) {
	TreeNode a, b;
	a = *(TreeNode*) a_pointer;
	b = *(TreeNode*) b_pointer;
	if (a->frequency > b->frequency) {
		return -1;
	} else if (a->frequency < b->frequency) {
		return 1;
	} else {
		return 0;
	}
}

TreeNode initHuffman(double frequency,
					 unsigned char value,
					 TreeNode left,
					 TreeNode right) {
	TreeNode huffman;
	huffman = malloc(sizeof(struct treeNode));
	huffman->left = left;
	huffman->right = right;
	huffman->value = value;
	huffman->frequency = frequency;
	huffman->idx = idx;
	return huffman;
}


TreeNode createHuffmanTree(char *text) {
	Pair pereche[100];
	int i, j;
	int nr = 0; // numarul de caractere distincte
	int ok;

	TreeNode min1, min2, newNode;
	TreeNode node;
	char* aux = strdup(text);
	// creez vectorul de asocieri caracter-frecventa corespunzator
	// textului dat ca parametru
	for (i = 0; i < strlen(aux); i++)
	{
		ok = 0; // pp ca nu am in vectorul de perechi caracterul aux[i]
		for (j = 0; j < nr; j++)
			if (pereche[j].value == aux[i])
			{
				pereche[j].appearances++;
				ok = 1;
			}
		if (ok == 0)
		{
			pereche[nr].value = aux[i];
			pereche[nr].appearances = 1;
			nr++;
		}

	}

	Heap minHeap = initHeap(&treeNode_compare);
	for (i = 0; i < nr; i++)
	{

		node = initHuffman(pereche[i].appearances/strlen(text), pereche[i].value, NULL, NULL);
		minHeap = insertHeap(minHeap, node);
	}
	//drawHeap(minHeap, 0, "huff.png");

	for (i = 0; i < nr - 1; i++)
	{
		node = initHuffman(0, '$', NULL, NULL);
		min1 = extractMax(minHeap);
		node->left = min1;
		min2 = extractMax(minHeap);
		node->right = min2;
		node->frequency = min1->frequency + min2->frequency;
		minHeap = insertHeap(minHeap, node);
	}

	return extractMax(minHeap);
}



void printCodes(TreeNode huffman, int index, int v[], int c)
{
	if (huffman->left == NULL && huffman->right == NULL)
	{
		if (huffman->value == c)
			for (int i = 0; i < index; i++)
				printf("%d", v[i]);
	}

	if (huffman->left != NULL)
	{
		v[index] = 0;
		printCodes(huffman->left, index + 1, v, c);
	}

	if (huffman->right != NULL)
	{
		v[index] = 1;
		printCodes(huffman->right, index + 1, v, c);
	}
}

void compress(TreeNode huffman, char *text) {
	int i;
	int v[10000];
	for (i = 0; i < strlen(text); i++)
		printCodes(huffman, 0, v, text[i]);
}



// parcurg stringul dat ca parametru; daca text[i] e 0, ma duc spre fiul stang;
// daca text[i] e 1, ma duc spre fiul drept; cand ajung la un nod care nu are nici
// fiu drept, nici fiu stang, inseamna ca am gasit un caracter al textului 
char *decompress(TreeNode huffman, char *text) {
	int i, Max = 10;
	TreeNode tmp = huffman;
	char* decode;
	int nr = 0;
	decode = malloc(Max * sizeof(char));
	for (i = 0; i < strlen(text); i++)
	{
		if (text[i] == '0')
			tmp = tmp->left;
		else
			tmp = tmp->right; 

		// am ajuns la un nod frunza
		if (tmp->left == NULL && tmp->right == NULL)
		{
			if (strlen(decode) == Max)
			{
				Max = 2 * Max;
				decode = realloc(decode, Max * sizeof(char));
			}

			decode[nr] = tmp->value;
			nr++;
			tmp = huffman;
		}
	}
	decode[nr] = '\0';
	return decode;
}

// functia decompress facuta din afisare
void decompress2(TreeNode huffman, char* text)
{
	int i;
	TreeNode tmp = huffman;
	for (i = 0; i < strlen(text); i++)
	{
		if (text[i] == '0')
			tmp = tmp->left;
		else
			tmp = tmp->right; 

		// am ajuns la un nod frunza
		if (tmp->left == NULL && tmp->right == NULL)
		{
			printf("%c", tmp->value);
			tmp = huffman;
		}
	}
	printf("\n");
}

TreeNode freeTree(TreeNode root) {
	return NULL;
}
