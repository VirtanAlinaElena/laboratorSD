#include "heap.h"

Heap initHeap(int (*compare_func) (const void*, const void*)) {
	Heap h;
	h = malloc(sizeof(struct heap)); 
	h->size = 0;
	h->capacity = MAX;
	h->compare_func = compare_func;
	return h;
}

void swap(Type v[], int i, int j)
{
	Type aux;
	aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

Heap siftDown(Heap h, int index) {
	int minIndex = index;
	int left = index * 2 + 1;
	int right = index * 2 + 2;

	if (left < h->size)
		if(h->compare_func(&h->vector[left], &h->vector[minIndex]) < 0)
			minIndex = left;

	if (right < h->size)
		if (h->compare_func(&h->vector[right], &h->vector[minIndex]) < 0)
			minIndex = right;

	if (index != minIndex)
	{
		swap(h->vector, index, minIndex);
		h = siftDown(h, minIndex);
	}
	return h;
}

Heap siftUp(Heap h, int index) {
	int parent;
	parent = (index - 1)/2;
	while (h->compare_func(&h->vector[index], &h->vector[parent]) < 0)
	{
		swap(h->vector, index, parent);
		index = parent;
		if (index == 0)
			break;
		parent = (index - 1) / 2;
	}
	return h;
}

Heap insertHeap(Heap h, Type element) {
	int index;

	if (h->size == 0)
	{
		h->vector[h->size] = element;
		h->size++;
		return h;
	}
	else
	{
		h->vector[h->size] = element;
		h->size++;
		index = h->size - 1;
		siftUp(h, index);

	}
	return h;
}

Type extractMax(Heap h) {
	int index, left, right;
	Type Min;
	Min = h->vector[0];
	h->vector[0] = h->vector[h->size - 1];
	h->size = h->size - 1;

	index = 0;
	h = siftDown(h, index);
	return Min;
}

Heap freeHeap(Heap h) {
	free(h);
	return h;
}
