#include <string.h>
#include "graph.h"

Graph initGraph(int V) {
	Graph g;
	int i;
	g = (Graph) malloc(sizeof(struct graph));
	g->V = V;
	g->adjLists = (List*) malloc(V * sizeof(List));
	for (i = 0; i < V; i++) {
		g->adjLists[i] = NULL;
	}
	g->visited = calloc(V, sizeof(int));
	g->start = malloc(V * sizeof(int));
	g->end = malloc(V * sizeof(int));
	return g;
}

Graph insertEdge(Graph g, int u, int v, int cost) {
	Pair p;
	p.v = v;
	p.cost = cost;
	g->adjLists[u] = addLast(g->adjLists[u], p);

	p.v = u;
	p.cost = cost;
	g->adjLists[v] = addLast(g->adjLists[v], p);
	return g;
}

int isArc(Graph g, int u, int v) {
	List tmp = g->adjLists[u];
	while (tmp != NULL) {
		if (tmp->data.v == v)
			return 1;
		tmp = tmp->next;
	}
	return 0;
}

int getCost(Graph g, int u, int v) {
	List tmp = g->adjLists[u];
	while (tmp != NULL) {
		if (tmp->data.v == v)
			return tmp->data.cost;
		tmp = tmp->next;
	}
	return INFINITY;
}

//Functie care va deseneaza graful
void drawGraph(Graph g, char *name)
{
	int i, j;
	FILE *stream;
	char *buffer, *aux;
	List tmp;

	if (g == NULL || name == NULL)
		return;
	stream = fopen(name, "w");
	fprintf(stream, "digraph G {\n");
	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
	for (i = 0; i < g->V; i++) {
		tmp = g->adjLists[i];
		while (tmp != NULL) {
			fprintf(stream, "    %d -> %d;\n", i, tmp->data.v);
			tmp = tmp->next;
		}
	}
	fprintf(stream, "}\n");
	fclose(stream);
	buffer = (char*) malloc(SIZE*sizeof(char));
	aux = (char*) malloc(SIZE*sizeof(char));
	strncpy(aux, name, strlen(name) - 4);
	sprintf(buffer, "dot %s.dot | neato -n -Tpng -o %s.png", aux, aux);
	system(buffer);
	free(buffer);
}

void Dijkstra(Graph g, int *parent, int *dist, int source) {
	Heap *h;
	int i, u, v, weight, INF = 999999;
	int *vizitat = malloc((g->V)*sizeof(int));
	int nod;
	List tmp;

	vizitat[source] = 1;
	h = new_heap(g->V, 0, NULL, MIN_h);
	for (i = 0; i < g->V; i++)
		if (isArc(g, source, i) == 1)
		{
			tmp = g->adjLists[source];
			while (tmp->data.v != i)
				tmp = tmp->next;
			dist[i] = tmp->data.cost;
			insert(h, i, dist[i]);
			parent[i] = source;
 		}
 		else
 		{
 			dist[i] = INF;
 			parent[i] = -1; // nu are parinte
 		}
 	while (h != NULL && h->size != 0)
 	{
 		u = pop(h, 0);
 		vizitat[u] = 1;
 		tmp = g->adjLists[u];
 		while (tmp != NULL)
 		{
 			v = tmp->data.v;
 			weight = tmp->data.cost;
 			if (!vizitat[v] && dist[v] > dist[u] + weight)
 			{
 				dist[v] = dist[u] + weight;
 				parent[v] = u;
 				insert(h, v, dist[v]);
 			}
 			tmp = tmp->next;
 		}
 	}
}

int cmp(const void *a, const void *b) {
	Edge m1, m2;
	m1 = *(Edge *) a;
	m2 = *(Edge *) b;
	return m1.cost - m2.cost;
}

Graph Kruskal(Graph g) {
	Graph AMA;
	int *status, i, count, capacity, j, x, *parent, *rnk, aux, u, v;
	Edge *edges, edge;
	capacity = g->V;
	edges = malloc(capacity * sizeof(struct edge));
	List tmp;

	// bag toate muchiile in vectorul edges
	count = 0;
	for (i = 0; i < g->V; i++)
	{
		tmp = g->adjLists[i];
		while (tmp != NULL)
		{
			edge.u = i;
			edge.v = tmp->data.v;
			edge.cost = tmp->data.cost;
			if (count == g->V)
			{
				capacity = 2 * capacity;
				edges = realloc(edges, capacity * sizeof(struct edge));
			}
			edges[count] = edge;
			count++;
			tmp = tmp->next;
		}
	}
	// ordonez muchiile in ordine crescatoare dupa cost
	for (i = 0; i < count - 1; i++)
		for (j = i + 1; j < count; j++)
			if (edges[i].cost > edges[j].cost)
			{
				edge = edges[i];
				edges[i] = edges[j];
				edges[j] = edge;
			}
	
	AMA = initGraph(g->V);
	int cost = 0;
	status = (int*) malloc(g->V * sizeof(int));
	for (i = 0; i < g->V; i++)
		status[i] = i;

	for (i = 0; i < count; i++)
	{
		u = edges[i].u;
		v = edges[i].v;

		if (status[u] != status[v])
		{
			aux = status[u];
			for (j = 0; j < g->V; j++)
				if (status[j] == aux)
					status[j] = status[v];
			AMA = insertEdge(AMA, u, v, edges[i].cost);
			cost += edges[i].cost;
		}
	}

	printf("%d\n", cost);
	return AMA;
}
