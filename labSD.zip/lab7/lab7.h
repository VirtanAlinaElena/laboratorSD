#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>

#define SIZE 200

typedef struct trie {
	char value;
	bool end;
	struct trie *child;
	struct trie *sibling;
} *Trie;

Trie initTrie(char value, bool end);
int noOfKids(Trie trie);
Trie insertChild(Trie trie, char value, bool end);
Trie getChild(Trie trie, char value);
Trie insertWord(Trie trie, char *word, int index);
bool containsWord(Trie trie, char *word, int index);
void drawTrie(Trie trie, char *fileName);
void autoSuggestions(Trie trie, char *word);
Trie deleteChild(Trie trie, char value);
Trie deleteWord(Trie trie, char *word, int index);
Trie freeTrie(Trie trie);
