#include "trie.h"

Trie initTrie(char value, bool end) {
	Trie trie;
	trie = (Trie) malloc(sizeof(struct trie));
	trie->value = value;
	trie->end = end;
	trie->child = NULL;
	trie->sibling = NULL;
	return trie;
}

// returneaza nr de copii pe care ii are radacina arborelui
int noOfKids(Trie trie) {
	Trie tmp;
	int kids = 0;
	if (trie->child != NULL)
	{
		tmp = trie->child;
		while (tmp != NULL)
		{
			kids++;
			tmp = tmp->sibling;
		}
	}
	return kids;
}

Trie insertChild(Trie trie, char value, bool end) {
	Trie tmp;
	if (trie == NULL)
		trie = initTrie(value, end);
	else
	{
		Trie aux;
		aux = initTrie(value, end);
		tmp = trie->child;
		if (trie->child == NULL)
		{
			trie->child = aux;
			return trie;
		}

		while (tmp->sibling != NULL)
			tmp = tmp->sibling;
		tmp->sibling = aux;
	}

	return trie;
}

Trie getChild(Trie trie, char value) {
	Trie tmp;
	if (trie != NULL)
		if (trie->value == value)
			return trie;
	
	if (trie->child != NULL)
	{	if (trie->child->value == value)
			return trie;
		tmp = trie->child;
		while (tmp->sibling != NULL)
		{
			if (tmp->sibling->value == value)
				return trie;
			tmp = tmp->sibling;
		}
	}

	return NULL;
}

Trie insertWord(Trie trie, char *word, int index) {
	Trie tmp;
	Trie aux;
	int level;

	tmp = trie;
	for (level = 0; level < strlen(word); level++)
	{
		// daca tmp are un copil cu litera corespunzatoare din word
		aux = getChild(tmp, word[level]);
		if (aux != NULL)
			tmp = aux;
		else
		{
			if (level == strlen(word) - 1 )
			{
				tmp = insertChild(tmp, word[level], 1);
				tmp = getChild(tmp, word[level], 1);
			}
			else
			{	tmp = insertChild(tmp, word[level], 0);
				tmp = getChild(tmp, word[level], 0);
			}
		}

	}

	return trie;
}

bool containsWord(Trie trie, char *word, int index) {
	
}

void drawTrieHelper(Trie trie, FILE* stream) {
	Trie tmp;
	if (trie == NULL) {
		return;
	}
	if (trie->end) {
		fprintf(stream, "    %ld[label=\"%c\", fillcolor=red]\n", (intptr_t) trie, trie->value);
	} else {
		fprintf(stream, "    %ld[label=\"%c\", fillcolor=blue]\n", (intptr_t) trie, trie->value);
	}
	tmp = trie->child;

	while (tmp != NULL) {
		fprintf(stream, "    %ld -> %ld \n", (intptr_t) trie, (intptr_t) tmp);
		drawTrieHelper(tmp, stream);
		tmp = tmp->sibling;
	}
}

void drawTrie(Trie trie, char *fileName) {
	FILE* stream = fopen("test.dot", "w");
	char buffer[SIZE];
	fprintf(stream, "digraph TRIE {\n");
	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
	if (!trie)
		fprintf(stream, "\n");
	else if (!trie->child)
		fprintf(stream, "    %ld [label=\"%c\"];\n", (intptr_t) trie, trie->value);
	else
		drawTrieHelper(trie, stream);
	fprintf(stream, "}\n");
	fclose(stream);
	sprintf(buffer, "dot test.dot | neato -n -Tpng -o %s", fileName);
	system(buffer);
}

Trie deleteChild(Trie trie, char value) {
	return NULL;
}

Trie deleteWord(Trie trie, char *word, int index) {
	return NULL;
}

Trie freeTrie(Trie trie) {
	return NULL;
}